﻿using System;

public class AList<T>
{
  
}
